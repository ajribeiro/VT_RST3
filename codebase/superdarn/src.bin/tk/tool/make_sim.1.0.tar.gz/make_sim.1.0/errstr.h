/* errstr.h 
   ======== 
   Author: R.J.Barnes
*/

/*
 $License$
*/

char *errstr[]={NULL};
