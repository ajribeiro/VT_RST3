/* hlpstr.h 
   ======== 
   Author: R.J.Barnes
*/

/*
 $License$
*/

char *hlpstr[]={NULL};
